#include <stdio.h>

int main()
{
  printf("Hello MSI 20220422\n");
  return 0;
 }
